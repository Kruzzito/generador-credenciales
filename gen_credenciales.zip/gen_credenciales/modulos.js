const form = document.getElementById("imageForm");
      const nameField = document.querySelector(".credAnverso .name");
      const emailField = document.querySelector(".credAnverso .email");
      const photoField = document.querySelector(".credAnverso .foto");

      // Enviar informacion del formulario a la credencial
      form.addEventListener("submit", function (event) {
        event.preventDefault();
        const formData = new FormData(form);
        const name = formData.get("name");
        const email = formData.get("email");
        const image = formData.get("image");

        nameField.textContent = name;
        emailField.textContent = email;

        if (image) {
          const reader = new FileReader();
          reader.onload = function (e) {
            const img = document.createElement("img");
            img.src = e.target.result;
            img.alt = "Foto de usuario";

            photoField.textContent = "";
            photoField.appendChild(img);
          };
          reader.readAsDataURL(image);
        }

        // Enviar los datos del formulario a Google Sheets
        const scriptURL =
          "https://script.google.com/macros/s/AKfycbxzDP4CXlhH8uoNXDdMS4LnRCHF-C7h_ix_CDvnGtdI7eZ3334_r10SdJbLomaTvU0/exec"; // Reemplaza con tu URL del script
        fetch(scriptURL, {
          method: "POST",
          body: new URLSearchParams({
            name: name,
            email: email,
          }),
        })
          .then((response) => response.json())
          .then((result) => {
            alert("Formulario enviado y credencial actualizada.");
          })
          .catch((error) =>
            console.error("Error al enviar los datos: ", error)
          );
      });

      // Imprimir la credencial
      document
        .querySelector(".imprimir")
        .addEventListener("click", function () {
          const printableContent =
            document.getElementById("printableArea").outerHTML;
          const originalContent = document.body.innerHTML;

          document.body.innerHTML = printableContent;
          window.print();
          document.body.innerHTML = originalContent;
        });